package com.example.jorgeperezcong.prueba;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class ComprarAlbum extends AppCompatActivity {
    private WebView wb;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_comprar_album);
        wb = (WebView)findViewById(R.id.wvHola);
        wb.loadUrl("http://tiendapanini.com.mx/coleccionables-album-oficial-mundial-rusia-2018.asp");
        wb.getSettings().setJavaScriptEnabled(true);
        wb.setWebViewClient(new WebViewClient());


    }
}
