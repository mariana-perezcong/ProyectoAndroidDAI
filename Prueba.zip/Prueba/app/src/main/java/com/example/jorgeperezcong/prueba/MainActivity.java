package com.example.jorgeperezcong.prueba;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    private EditText usuario, contra;
    AdminSQLLiteOpenHelper db;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        usuario = (EditText)findViewById(R.id.etUsuario);
        contra = (EditText)findViewById(R.id.etContra);
        db=new AdminSQLLiteOpenHelper(this);

    }

    public void ingresar(View v){
        String us= usuario.getText().toString();
        String con= contra.getText().toString();
        boolean chk= db.usuarioContra(us,con);
        if(chk==true){
            Intent intent= new Intent(MainActivity.this, Menu.class);//(donde estoy, a donde quiero ir)
            Bundle b=new Bundle();
            b.putString("Nombre",us);
            intent.putExtras(b);
            startActivity(intent);
        }else
            Toast.makeText(this, "Usuario o contraseña incorrectos", Toast.LENGTH_SHORT).show();
    }


    public void crearCuenta(View v){
        Intent intent= new Intent (MainActivity.this,CrearCuenta.class);
        startActivity(intent);
    }


}

