package com.example.jorgeperezcong.prueba;

import android.content.ContentValues;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class CrearCuenta extends AppCompatActivity {

    AdminSQLLiteOpenHelper db;

    public EditText nUsuario, nContra;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_crear_cuenta);
        nUsuario=(EditText) findViewById(R.id.etNvoUsuario);
        nContra=(EditText)findViewById(R.id.etNvoContra);
        db=new AdminSQLLiteOpenHelper(this);
    }
    public void crearCuenta(View v){
        boolean chkUsuario= db.checkUsuario(nUsuario.getText().toString());
        if(chkUsuario==true){
            boolean insert=db.insert(nUsuario.getText().toString(),nContra.getText().toString());
            if(insert==true){
                Toast.makeText(this, "Registro exitoso", Toast.LENGTH_SHORT ).show();
            }
        }else
            Toast.makeText(this, "Usuario inválido. Intente con otro", Toast.LENGTH_SHORT).show();
    }
}
