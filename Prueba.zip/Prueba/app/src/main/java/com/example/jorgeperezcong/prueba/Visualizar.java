package com.example.jorgeperezcong.prueba;

import android.database.Cursor;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.Toast;

import java.util.ArrayList;

public class Visualizar extends AppCompatActivity {
    String usuario;
    AdminSQLLiteOpenHelper db;
    ListView myListView;
    Spinner s;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_visualizar);
        Bundle bundle=this.getIntent().getExtras();
        usuario=bundle.get("Nombre").toString();
        db=new AdminSQLLiteOpenHelper(this);
        myListView=(ListView) findViewById(R.id.lvEstampas);

        String[]arraySpinner=new String[]{"Lista completa", " "};
        s= (Spinner) findViewById(R.id.Spinner01);
        ArrayAdapter <String> adapter= new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, arraySpinner);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        s.setAdapter(adapter);

    }
    public void populateListView(View v){
        int sel=s.getSelectedItemPosition();
        Toast.makeText(this, "Selecciono index "+sel,Toast.LENGTH_SHORT).show();
        Cursor data;
        if(sel==0){
            data=db.getData(usuario);
            Toast.makeText(this, "Lista completa de estampas", Toast.LENGTH_SHORT).show();

        }else{
            data=db.getDataRep(usuario);
            Toast.makeText(this, "Lista de estampas repetidas", Toast.LENGTH_SHORT).show();
        }

        ArrayList <String> listData=new ArrayList<>();
        while(data.moveToNext()){
            listData.add(data.getString(0));
        }
        ListAdapter adapter=new ArrayAdapter<>(this, android.R.layout.simple_list_item_1,listData);
        myListView.setAdapter(adapter);

    }

}
