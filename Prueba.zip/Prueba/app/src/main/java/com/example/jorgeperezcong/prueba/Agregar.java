package com.example.jorgeperezcong.prueba;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class Agregar extends AppCompatActivity {
    String usuario;
    EditText estampa;
    AdminSQLLiteOpenHelper db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_agregar);
        Bundle bundle=this.getIntent().getExtras();
        usuario=bundle.get("Nombre").toString();
        estampa=(EditText)findViewById(R.id.etNumEstampa);
        db=new AdminSQLLiteOpenHelper(this);
    }
    public void agregar(View v){
        String es= estampa.getText().toString();
        boolean insert=db.insertStamp(usuario, es);
        if(insert==true){
            Toast.makeText(this, "Registro exitoso", Toast.LENGTH_SHORT).show();
        }else
            Toast.makeText(this, "Error al ingresar estampa", Toast.LENGTH_SHORT).show();

    }


}
