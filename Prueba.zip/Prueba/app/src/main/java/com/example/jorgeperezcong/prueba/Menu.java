package com.example.jorgeperezcong.prueba;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.TextureView;
import android.view.View;
import android.widget.Toast;

public class Menu extends AppCompatActivity {
    private String nombre;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);
        Bundle bundle=this.getIntent().getExtras();
        nombre=bundle.get("Nombre").toString();
        Toast.makeText(this, "Hola "+nombre,Toast.LENGTH_LONG).show();


    }
    public void visualizar(View v){
        Intent intent= new Intent(Menu.this, Visualizar.class);//(donde estoy, a donde quiero ir)
        Bundle b=new Bundle();
        b.putString("Nombre",nombre);
        intent.putExtras(b);
        startActivity(intent);
    }
    public void eliminar(View v){
        Intent intent= new Intent(Menu.this, Eliminar.class);//(donde estoy, a donde quiero ir)
        Bundle b=new Bundle();
        b.putString("Nombre",nombre);
        intent.putExtras(b);
        startActivity(intent);
    }
    public void agregar(View v){
        Intent intent= new Intent(Menu.this, Agregar.class);//(donde estoy, a donde quiero ir)
        Bundle b=new Bundle();
        b.putString("Nombre",nombre);
        intent.putExtras(b);
        startActivity(intent);
    }
    public void pagina(View v){
        Intent intent= new Intent(Menu.this, ComprarAlbum.class);//(donde estoy, a donde quiero ir)
        Bundle b=new Bundle();
        b.putString("Nombre",nombre);
        intent.putExtras(b);
        startActivity(intent);
    }







}
