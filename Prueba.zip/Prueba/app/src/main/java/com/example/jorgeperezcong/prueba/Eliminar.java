package com.example.jorgeperezcong.prueba;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class Eliminar extends AppCompatActivity {
    String usuario;
    AdminSQLLiteOpenHelper db;
    EditText numEstampa;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_eliminar);
        Bundle bundle=this.getIntent().getExtras();
        usuario=bundle.get("Nombre").toString();
        db=new AdminSQLLiteOpenHelper(this);
        numEstampa=(EditText) findViewById(R.id.etNumEstampa);
    }
    public void eliminar(View v){
        String numEs=numEstampa.getText().toString();
        db.deleteStamp(numEs, usuario);
        Toast.makeText(this, "Se elimino esa estampa satisfactoriamente", Toast.LENGTH_SHORT).show();
    }
}
